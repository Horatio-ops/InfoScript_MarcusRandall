Simple Information Script | Marcus Randall (Horatio)

##############################################
# Welcome to my awesome unit convertor tool. #
# The simple script uses Zenity and advance  # 
# scripting concepts. I hope you enjoy this  #
# did as it took me some time to create :)   #
#                                            #
# Don't forget to leave a like and comment!  #
#                                            #
#         (⌐■_■) Peace out dudes!            #
##############################################
# ------------------------------------------ #
#    Accredited Aurthor: Marcus Randall      #
# ------------------------------------------ #
# Check out my other programs and scrpts on: #
#   Github account github.com/Horatio-ops    #
# ------------------------------------------ #
#          Get in contact with me:           #
#         marcusrandall06@gmail.com          #
#        mr156603@truro-penwith.ac.uk        #
# -------------------------------------------#
# If you do use my work, please reference it #
##############################################

Install guide: 
 1. Download the zip file.
 2. Extract file content.
 3. Access terminal console.
 4. Locate file directory.
 5. Run "/conv_unit" command in the terminal and enjoy!

Problems.
 - Permission denied: Enter “chmod u+x conv_unit.sh” in terminal.
 - If you encounter any issues please contact me.

Features:
 - Detail info about your system specs.
 - Serveral functions.
 
